<!DOCTYPE html>
<html>
<head>
    <title>Test Page</title>
</head>
<body>
    <h1>Zendesk App Server Test</h1>
    <p>If you can see this, your server is serving static files correctly.</p>
</body>
</html>
